<!doctype html>
<html lang="en">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
  <header>
    <!-- place navbar here -->
  </header>
  


<!-- form action redirect on the laravel base url which is in the .env folder -->
<!-- and also have to use crftoken because when you are sending data through post method you need to use this -->

<form action ="{{url('/')}}/register" method="post">
    @csrf

    <!-- to print the validation error or to show the validation error so that user may  know what error they are getting after submiting the form-->
<!-- <pre> -->
    <!-- errors->all() show us client side validation error -->

    <!-- @php 
    print_r($errors->all());
    @endphp -->
<!-- </pre> -->

<div class="container">
<h1 class="text-center">Registration</h1>

<div class="form-group">
    <label for="my-input">Name</label>
    <input type ="text" name="name" id="" class="form-control" placeholder="enter a name" aria-describedby="helpId"/>
    
    <!-- helps to display error after ever new input field -->
    <span class="text-danger">

     @error('name')
     {{$message}}
     @enderror
     </span>
</div>
<br>

<div class="form-group">
    <label for="my-input">E-mail</label>
    <input type ="email" name="email" id="" class="form-control" placeholder="enter email" aria-describedby="helpId"/>
  <!-- helps to display error after ever new input field -->
  <span class="text-danger">

@error('email')
{{$message}}
@enderror
</span>
</div>
<br>
<div class="form-group">
    <label for="my-input">password</label>
    <input type ="password" name="password" id="" class="form-control" placeholder="enter a password" aria-describedby="helpId"/>
  <!-- helps to display error after ever new input field -->
  <span class="text-danger">

@error('password')
{{$message}}
@enderror
</span>
</div>
<br>
<div class="form-group">
    <label for="my-input">confirm-password</label>
    <input type ="password" name="password_confirmation" id="" class="form-control" placeholder="*****" aria-describedby="helpId"/>
  <!-- helps to display error after ever new input field -->
  <span class="text-danger">

@error('password_confirmation')
{{$message}}
@enderror
</span>
</div>
<br>

<button class="btn btn-primary">Submit</button>


</div>
</form>

</body>

</html>