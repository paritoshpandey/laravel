<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegistrationController extends Controller
{
    //
    public function index(){
        return view('forms');
    }

// to show the data sent by user
public function register(Request $request){

    // for validating server side 

    $request ->validate(
        [
    // you can check in resources/lang/en/validation.php file 
            'name' => 'required',
            'email' => 'required | email',
            'password' => 'required | confirmed',

            // if you want validation on confirmation password that means password = confirmation_password but you have also need to change the field value in forms.blade.php file and have to set 'password_confirmation'

            'password_confirmation' => 'required'
        ]
        );
    echo "<pre>";
   print_r($request->all());
}
}
