<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>getting form data</title>
</head>
<body>

<<table class="table table-light">
    <thead>
    <tr>
            <th> Name </th>
            <th>  Email </th>
            <th>  Password </th>
            <th>  Password_confirmation </th>
        </tr>
        
</thead>
    <tbody>
        <tr> 
            <td>
               
</td>
</tr>
    </tbody>
</table>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\new_project\resources\views/register_data.blade.php ENDPATH**/ ?>