<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    hello to my new project <?php echo e(date('d-m-y')); ?>


</body>
</html><?php /**PATH C:\xampp\htdocs\new_project\resources\views/welcome.blade.php ENDPATH**/ ?>